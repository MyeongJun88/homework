i=100
while i % 23 != 0:
    i += 1

print(i)
name = 'tom'
nationality = 'korea'
phone_number = '010-1234-5678'

print("Hi, my name is %s . I'm from %s "%(name, nationality))
print("My phone number is %s."%(phone_number))






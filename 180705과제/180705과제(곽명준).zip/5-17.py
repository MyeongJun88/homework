i=1
if 120 % i == 0 :
    print(i)

elif 120 % i != 0:
    i += 1
continue

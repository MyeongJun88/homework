def print_full_name(firstname, lastname):
    print("%s, %s"%(lastname, firstname))

print_full_name("윤수", "이")
print_full_name("수민", "이")


for i in range(0,11):
    print("2^%d=%d" % (i, 2**i))






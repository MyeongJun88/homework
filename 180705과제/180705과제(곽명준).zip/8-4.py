numbers = [2, 3, 5, 7, 11, 13, 17, 19]
for i in range (len(numbers)):
    print(i , numbers [i])
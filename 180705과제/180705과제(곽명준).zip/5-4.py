i=2
while i<= 100:
    print (i)
    i=i+2


class Groupper(object):
    def __init__(self, names):
        self.names = names

    def random_group(self, group_count):
        pass

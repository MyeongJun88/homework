# TODO : implement WatingList.


class WaitingList(object):
    def __init__(self):
        pass

    def add_customer(self, name):
        pass

    def print_current_list(self):
        pass

    def pop_customer(self):
        pass

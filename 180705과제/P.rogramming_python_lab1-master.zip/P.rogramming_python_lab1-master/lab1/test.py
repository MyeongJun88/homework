from waiting_list import WaitingList


def test():
    wating_list = WatingList()
    # TODO : Something To Test Here!!!


if __name__ == '__main__':
    test()
